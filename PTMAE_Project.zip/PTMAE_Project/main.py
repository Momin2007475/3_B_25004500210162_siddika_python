"""
PTMAE — Pure Python Transactional Micro-Banking & Audit Engine
Python 3.x; imports are limited to the SRS-approved modules: random and datetime.
"""

import random
import datetime


# ============================================================
# MODULE 1 — State Control Engine and Trajectory Guards (Unit 1)
# ============================================================

def compound_interest(principal, rate_percent, periods):
    """Calculate compound interest using arithmetic operators only."""
    amount = principal
    period = 0
    while period < periods:
        amount = amount * (1 + rate_percent / 100)
        period += 1
    return amount - principal


def calculate_penalty(amount, penalty_percent, fixed_fee=0):
    """Calculate a percentage penalty plus a fixed fee using arithmetic only."""
    return amount * penalty_percent / 100 + fixed_fee


def trajectory_guard(starting_balance, transactions, safety_threshold=0):
    """Return processed balances and stop early on low balance or a stop flag."""
    balance = starting_balance
    history = []
    index = 0
    while index < len(transactions):
        item = transactions[index]
        # Each item is (amount, termination_flag); short-circuit OR guards both exits.
        if balance < safety_threshold or item[1]:
            break
        balance += item[0]
        history.append(balance)
        index += 1
    return balance, history, index


def command_loop():
    """Run the interactive nested-while command loop until explicit exit."""
    print("\\nPTMAE command loop. Commands: balance, interest, penalty, exit")
    balance = 5000.0
    running = True
    while running:
        valid_command = False
        while not valid_command:
            command = input("PTMAE> ").strip().lower()
            if command == "exit":
                valid_command = True
                running = False
            elif command == "balance":
                print("Current demonstration balance: {:.2f}".format(balance))
                valid_command = True
            elif command == "interest":
                try:
                    principal = float(input("Principal: "))
                    rate = float(input("Annual rate (%): "))
                    periods = int(input("Periods: "))
                    if principal < 0 or rate < 0 or periods < 0:
                        print("Values must be non-negative.")
                    else:
                        print("Compound interest: {:.2f}".format(compound_interest(principal, rate, periods)))
                except ValueError:
                    print("Invalid numeric input; please try again.")
                valid_command = True
            elif command == "penalty":
                try:
                    amount = float(input("Transaction amount: "))
                    rate = float(input("Penalty rate (%): "))
                    fee = float(input("Fixed fee: "))
                    if amount < 0 or rate < 0 or fee < 0:
                        print("Values must be non-negative.")
                    else:
                        print("Penalty: {:.2f}".format(calculate_penalty(amount, rate, fee)))
                except ValueError:
                    print("Invalid numeric input; please try again.")
                valid_command = True
            else:
                print("Unknown command. Choose balance, interest, penalty, or exit.")
                valid_command = True


# ============================================================
# MODULE 2 — Native Log Parser and Closure Mechanics (Unit 2)
# ============================================================

def parse_raw_log_line(line, delimiter=",", quote_char='"'):
    """Parse a delimited line manually, respecting quotes and doubled quote escapes."""
    tokens = []
    token = ""
    in_quotes = False
    index = 0
    while index < len(line):
        char = line[index]
        if char == quote_char:
            if in_quotes:
                if index + 1 < len(line) and line[index + 1] == quote_char:
                    token += quote_char
                    index += 1
                else:
                    in_quotes = False
            else:
                in_quotes = True
        elif char == delimiter and not in_quotes:
            tokens.append(token.strip())
            token = ""
        else:
            token += char
        index += 1
    tokens.append(token.strip())
    if in_quotes:
        raise ValueError("Unclosed quoted field")
    return tokens


def create_audit_filter(threshold):
    """Create an independent audit filter whose closure counts qualifying records."""
    audited_count = 0

    def validate(record):
        """Return whether record meets threshold and update this filter's count."""
        nonlocal audited_count
        qualifies = record >= threshold
        if qualifies:
            audited_count += 1
        return qualifies

    def get_count():
        """Return this filter's cumulative qualifying-record count."""
        return audited_count

    validate.get_count = get_count
    return validate


def build_positional_filters(criteria):
    """Build positional lambda filters while binding each loop index immediately."""
    filters = []
    index = 0
    while index < len(criteria):
        criterion = criteria[index]
        filters.append(lambda transaction, k=index, expected=criterion:
                       len(transaction) > k and transaction[k] == expected)
        index += 1
    return filters


# ============================================================
# MODULE 3 — Data Inversion and In-Place Processing (Unit 3)
# ============================================================

def build_reverse_index(raw_db):
    """Build service-tag to sorted unique (account ID, branch ID) tuples."""
    return {
        service: sorted(set((account_id, branch_id)
                            for branch_id, records in raw_db.items()
                            for account_id, services in records
                            for tag in services if tag == service))
        for service in {tag for records in raw_db.values()
                        for account_id, services in records for tag in services}
    }


def clean_transaction_queue(data_list):
    """Clean a heterogeneous list in place, preserving its top-level identity."""
    index = 0
    while index < len(data_list):
        value = data_list[index]
        if isinstance(value, tuple):
            data_list[index] = list(value)
            data_list[index].sort(reverse=True)
        elif isinstance(value, set):
            evens = set()
            for item in value:
                if isinstance(item, int) and item % 2 == 0:
                    evens.add(item)
            data_list[index] = value - evens
        elif isinstance(value, list):
            value.sort(reverse=True)
        index += 1

    # Remove duplicate primitive values in-place by scanning and deleting by index.
    index = 0
    while index < len(data_list):
        current = data_list[index]
        if isinstance(current, (str, int, float, bool, bytes, type(None))):
            earlier = 0
            duplicate = False
            while earlier < index:
                previous = data_list[earlier]
                if isinstance(previous, (str, int, float, bool, bytes, type(None))):
                    if type(previous) is type(current) and previous == current:
                        duplicate = True
                        break
                earlier += 1
            if duplicate:
                del data_list[index]
            else:
                index += 1
        else:
            index += 1
    return data_list


# ============================================================
# MODULE 4 — Transactional File Modifier and Error Logger (Unit 4)
# ============================================================

class BaseSystemError(Exception):
    """Base exception for PTMAE record and settlement errors."""


class CorruptedRecordError(BaseSystemError):
    """Raised when an account record has invalid fields or values."""


class OutOfBoundsError(BaseSystemError):
    """Raised when a requested value or operation is outside allowed bounds."""


class InsufficientBalanceError(BaseSystemError):
    """Raised when an account cannot cover a requested settlement."""


def _read_account_record(line):
    """Validate one account record and return (account_id, type, balance)."""
    fields = parse_raw_log_line(line.rstrip("\\r\\n"))
    if len(fields) != 3:
        raise CorruptedRecordError("Expected three comma-separated fields")
    account_id = fields[0].strip()
    account_type = fields[1].strip().upper()
    if not account_id or account_type not in ("SAVINGS", "CURRENT", "CREDIT"):
        raise CorruptedRecordError("Missing account ID or unknown account type")
    try:
        balance = float(fields[2])
    except ValueError:
        raise CorruptedRecordError("Balance is not numeric")
    if balance < 0:
        raise CorruptedRecordError("Balance must be non-negative")
    return account_id, account_type, balance


def _shift_file_tail(file_obj, source_start, destination_start, file_end, chunk_size=4096):
    """Shift bytes after a record using bounded chunks, without rewriting the whole file."""
    if destination_start > source_start:
        remaining = file_end - source_start
        while remaining > 0:
            amount = chunk_size
            if amount > remaining:
                amount = remaining
            read_start = source_start + remaining - amount
            file_obj.seek(read_start)
            chunk = file_obj.read(amount)
            file_obj.seek(destination_start + remaining - amount)
            file_obj.write(chunk)
            remaining -= amount
    elif destination_start < source_start:
        position = source_start
        while position < file_end:
            file_obj.seek(position)
            chunk = file_obj.read(chunk_size)
            if not chunk:
                break
            file_obj.seek(destination_start + (position - source_start))
            file_obj.write(chunk)
            position += len(chunk)
        file_obj.truncate(destination_start + (file_end - source_start))


def update_account_record_in_place(account_id, new_balance, db_path="accounts.db"):
    """Update one record in r+ binary mode and preserve all neighboring bytes."""
    if new_balance < 0:
        raise OutOfBoundsError("Balance cannot be negative")
    target = (account_id + ",").encode("utf-8")
    processed = 0
    rejected = 0
    line_number = 0
    try:
        with open(db_path, "r+b") as db:
            while True:
                line_start = db.tell()
                line = db.readline()
                if not line:
                    break
                line_number += 1
                try:
                    parsed = _read_account_record(line.decode("utf-8"))
                    processed += 1
                    if line.startswith(target):
                        old_end = db.tell()
                        old_record = line
                        newline = b"\\n" if old_record.endswith(b"\\n") else b""
                        new_record = (parsed[0] + ", " + parsed[1] + ", " +
                                      format(new_balance, ".2f")).encode("utf-8") + newline
                        file_end = db.seek(0, 2)
                        db.seek(old_end)
                        tail = file_end - old_end
                        # For growing records, shift from the end backwards.
                        if len(new_record) > len(old_record):
                            extra = len(new_record) - len(old_record)
                            remaining = tail
                            while remaining > 0:
                                amount = 4096 if remaining > 4096 else remaining
                                read_start = old_end + remaining - amount
                                db.seek(read_start)
                                chunk = db.read(amount)
                                db.seek(read_start + extra)
                                db.write(chunk)
                                remaining -= amount
                        elif len(new_record) < len(old_record):
                            extra = len(old_record) - len(new_record)
                            position = old_end
                            while position < file_end:
                                db.seek(position)
                                chunk = db.read(4096)
                                if not chunk:
                                    break
                                db.seek(position - extra)
                                db.write(chunk)
                                position += len(chunk)
                            db.truncate(file_end - extra)
                        db.seek(line_start)
                        db.write(new_record)
                        db.flush()
                        with open("ledger.txt", "a", encoding="utf-8") as ledger:
                            ledger.write("{} | balance updated to {:.2f} | {}\\n".format(
                                account_id, new_balance, datetime.datetime.now().isoformat(timespec="seconds")))
                        return True
                except (ValueError, UnicodeDecodeError, CorruptedRecordError, OutOfBoundsError) as error:
                    rejected += 1
                    with open("corrupted.log", "a", encoding="utf-8") as log:
                        log.write("Line {}: {} | {}\\n".format(line_number, repr(line), str(error)))
            if not target:
                raise OutOfBoundsError("Account ID not found")
        raise OutOfBoundsError("Account ID '{}' not found".format(account_id))
    except (OSError, BaseSystemError) as error:
        print("Record update error: {}".format(error))
        raise
    finally:
        print("File update run finished: {} valid record(s) scanned; {} rejected record(s).".format(
            processed, rejected))


def process_accounts_file(db_path="accounts.db"):
    """Validate records and log every accepted/rejected row with fault isolation."""
    processed = 0
    rejected = 0
    try:
        with open(db_path, "r", encoding="utf-8") as source:
            line_number = 0
            for line in source:
                line_number += 1
                try:
                    record = _read_account_record(line)
                    processed += 1
                    with open("ledger.txt", "a", encoding="utf-8") as ledger:
                        ledger.write("VALID {} | {} | {} | {:.2f}\\n".format(
                            line_number, record[0], record[1], record[2]))
                except (ValueError, CorruptedRecordError, UnicodeDecodeError) as error:
                    rejected += 1
                    with open("corrupted.log", "a", encoding="utf-8") as log:
                        log.write("Line {}: {} | {}\\n".format(line_number, line.rstrip(), str(error)))
    except OSError as error:
        print("Could not process accounts file: {}".format(error))
    finally:
        print("File processing complete: {} processed; {} rejected.".format(processed, rejected))
    return processed, rejected


# ============================================================
# MODULE 5 — Object-Oriented Architecture and Polymorphic Engine
# ============================================================

class Account:
    """Base account with private balance and protected account identifier."""
    total_accounts = 0

    def __init__(self, account_id, balance):
        """Create an account after validating its ID and opening balance."""
        self._account_id = account_id
        self.__balance = 0.0
        self.set_balance(balance)
        Account.total_accounts += 1

    def get_balance(self):
        """Return the private account balance."""
        return self.__balance

    def set_balance(self, value):
        """Set a non-negative numeric balance or raise a suitable exception."""
        if not isinstance(value, (int, float)) or isinstance(value, bool):
            raise OutOfBoundsError("Balance must be numeric")
        if value < 0:
            raise OutOfBoundsError("Balance cannot be negative")
        self.__balance = float(value)

    def get_account_id(self):
        """Return the account identifier."""
        return self._account_id

    def set_account_id(self, value):
        """Set a non-empty string account identifier."""
        if not isinstance(value, str) or not value.strip():
            raise OutOfBoundsError("Account ID must be a non-empty string")
        self._account_id = value.strip()

    def process_settlement(self, amount):
        """Base settlement deducts an amount when the balance permits."""
        if not isinstance(amount, (int, float)) or isinstance(amount, bool) or amount < 0:
            raise OutOfBoundsError("Transaction amount must be a non-negative number")
        if self.__balance < amount:
            raise InsufficientBalanceError("Insufficient balance")
        self.__balance -= amount
        return self.__balance


class SavingsAccount(Account):
    """Savings account must retain at least 1000 after a settlement."""
    def process_settlement(self, amount):
        """Deduct only when at least 1000 remains in savings."""
        if not isinstance(amount, (int, float)) or isinstance(amount, bool) or amount < 0:
            raise OutOfBoundsError("Transaction amount must be non-negative")
        if self.get_balance() - amount < 1000:
            raise InsufficientBalanceError("Savings account must retain 1000")
        self.set_balance(self.get_balance() - amount)
        return self.get_balance()


class CurrentAccount(Account):
    """Current account supports overdraft up to a private limit."""
    def __init__(self, account_id, balance, overdraft_limit=2000):
        """Initialise through super and store the private overdraft limit."""
        super().__init__(account_id, balance)
        if overdraft_limit < 0:
            raise OutOfBoundsError("Overdraft limit cannot be negative")
        self.__overdraft_limit = float(overdraft_limit)

    def process_settlement(self, amount):
        """Deduct an amount while respecting the overdraft limit."""
        if not isinstance(amount, (int, float)) or isinstance(amount, bool) or amount < 0:
            raise OutOfBoundsError("Transaction amount must be non-negative")
        effective_balance = self.get_balance() - getattr(self, "_CurrentAccount__overdraft_used", 0.0)
        new_balance = effective_balance - amount
        if new_balance < -self.__overdraft_limit:
            raise InsufficientBalanceError("Overdraft limit exceeded")
        self.set_balance(new_balance if new_balance >= 0 else 0)
        if new_balance < 0:
            # Keep the overdraft position separately while exposing available balance.
            self.__overdraft_used = -new_balance
        else:
            self.__overdraft_used = 0.0
        return new_balance


class CreditAccount(Account):
    """Credit account applies a 2.5 percent surcharge against its credit limit."""
    def __init__(self, account_id, balance, credit_limit=10000):
        """Initialise through super and store a private credit limit."""
        super().__init__(account_id, balance)
        if credit_limit < 0:
            raise OutOfBoundsError("Credit limit cannot be negative")
        self.__credit_limit = float(credit_limit)

    def process_settlement(self, amount):
        """Charge amount plus 2.5 percent surcharge against the credit limit."""
        if not isinstance(amount, (int, float)) or isinstance(amount, bool) or amount < 0:
            raise OutOfBoundsError("Transaction amount must be non-negative")
        charge = amount + amount * 2.5 / 100
        effective_balance = self.get_balance() - getattr(self, "_CreditAccount__credit_used", 0.0)
        new_balance = effective_balance - charge
        if new_balance < -self.__credit_limit:
            raise InsufficientBalanceError("Credit limit exceeded")
        self.set_balance(new_balance if new_balance >= 0 else 0)
        self.__credit_used = -new_balance if new_balance < 0 else 0.0
        return new_balance


def execute_batch_settlement(account_list, transaction_amount):
    """Settle each account independently and report successes and failures."""
    successes = []
    failures = []
    index = 0
    while index < len(account_list):
        account = account_list[index]
        try:
            result = account.process_settlement(transaction_amount)
            successes.append((account.get_account_id(), result))
            print("Settlement successful for {}: {}".format(account.get_account_id(), result))
        except (BaseSystemError, ValueError, TypeError) as error:
            failures.append((account.get_account_id(), str(error)))
            print("Settlement failed for {}: {}".format(account.get_account_id(), error))
        index += 1
    return successes, failures


# ============================================================
# Demonstration and executable entry point
# ============================================================

def run_demonstrations():
    """Exercise the parser, closures, inversion, queue, files, and OOP requirements."""
    print("\\n=== PTMAE demonstration ===")
    print("Compound interest (1000, 5%, 2 periods): {:.2f}".format(
        compound_interest(1000, 5, 2)))
    print("Penalty (500, 2%, fixed 3): {:.2f}".format(calculate_penalty(500, 2, 3)))
    balance, history, stopped_at = trajectory_guard(1500, [(100, False), (-700, False), (50, True), (100, False)], 1000)
    print("Trajectory guard: balance={}, history={}, stopped_at={}".format(balance, history, stopped_at))

    examples = [
        'Acc101,"SAVINGS, PREMIUM",5200.00',
        '"Customer ""A""",UPI,100',
        'Acc101,SAVINGS,'
    ]
    for example in examples:
        print("Parsed {} -> {}".format(repr(example), parse_raw_log_line(example)))

    audit = create_audit_filter(100)
    print("Audit results:", audit(90), audit(150), audit(200), "count:", audit.get_count())
    filters = build_positional_filters(["DEPOSIT", "UPI"])
    print("Lambda filters:", [filters[0](("DEPOSIT", "UPI")), filters[1](("DEPOSIT", "UPI"))])

    raw_db = {
        "BRANCH_01": [("Acc101", {"DEPOSIT", "UPI"}), ("Acc102", {"LOAN", "UPI"})],
        "BRANCH_02": [("Acc101", {"SAVINGS", "UPI"}), ("Acc103", {"CARD", "DEPOSIT"})]
    }
    print("Reverse index:", build_reverse_index(raw_db))
    queue = [(1, 2), [2, 8, 3], {1, 2, 3, 4}, 7, 7, "TX"]
    original_id = id(queue)
    clean_transaction_queue(queue)
    print("Cleaned queue:", queue, "identity unchanged:", id(queue) == original_id)

    # The sample file is created only if absent, so user data is never silently replaced.
    try:
        with open("accounts.db", "r", encoding="utf-8"):
            pass
    except OSError:
        with open("accounts.db", "w", encoding="utf-8") as sample:
            sample.write("Acc101, SAVINGS, 5200.00\\n")
            sample.write("Acc102, CURRENT, 1200.00\\n")
            sample.write("Acc103, CREDIT, 2500.00\\n")
            sample.write("CORRUPTED, UNKNOWN, not-a-number, extra\\n")
    process_accounts_file()

    savings = SavingsAccount("SAV-1", 5000)
    current = CurrentAccount("CUR-1", 1000, 1500)
    credit = CreditAccount("CRD-1", 1000, 3000)
    print("Name-mangled demonstration:", savings._Account__balance)
    try:
        print(savings.__balance)
    except AttributeError:
        print("Expected AttributeError for savings.__balance (name mangling works).")
    execute_batch_settlement([savings, current, credit], 500)
    print("Total account objects:", Account.total_accounts)


def main():
    """Run demonstrations then offer the interactive CLI until the user exits."""
    run_demonstrations()
    command_loop()


if __name__ == "__main__":
    main()
