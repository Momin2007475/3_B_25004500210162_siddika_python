# PTMAE — Project Documentation

## 1. Project overview

**Project name:** Pure Python Transactional Micro-Banking & Audit Engine (PTMAE)  
**Specification:** PTMAE-SRS-1.0  
**Language:** Python 3.x  
**Interface:** Command-line interface (CLI)  
**Storage:** UTF-8 plain-text files; no database engine and no GUI.

This project implements the five required modules in a single `main.py` file. It uses only the SRS-approved imports, `random` and `datetime`; the implementation currently uses `datetime` for ledger timestamps. No pip installation is required.

## 2. Folder structure

```text
PTMAE_Project/
├── main.py              # Complete executable program: all five modules and demonstrations
├── Documentation.md     # This documentation, diagrams, scope table and compliance checklist
├── accounts.db          # Sample text records; created by main.py only if missing
├── ledger.txt            # Created/appended when valid records or updates are processed
└── corrupted.log         # Created/appended when invalid records are rejected
```

`ledger.txt` and `corrupted.log` are runtime outputs and may not exist until the program is run. Do not put passwords or sensitive real banking data in these demonstration files.

## 3. How to run

1. Install Python 3.x if it is not already installed.
2. Extract the ZIP archive.
3. Open a terminal/command prompt in the extracted `PTMAE_Project` folder.
4. Run:

```bash
python main.py
```

The program first runs demonstrations for the SRS requirements, then starts the interactive CLI. Available CLI commands are `balance`, `interest`, `penalty`, and `exit`. Type `exit` to finish.

## 4. Architecture diagram

```text
                         +----------------------+
                         |       main()         |
                         +----------+-----------+
                                    |
                 +------------------+------------------+
                 |                  |                  |
       +---------v--------+ +-------v--------+ +-------v--------+
       | Module 1         | | Module 2       | | Module 3       |
       | CLI / arithmetic | | Parser/closures| | Reverse index  |
       | trajectory guard | | audit lambdas  | | in-place queue |
       +------------------+ +----------------+ +----------------+
                 |                  |                  |
                 +------------------+------------------+
                                    |
                         +----------v-----------+
                         | Module 4             |
                         | accounts.db          |
                         | ledger.txt           |
                         | corrupted.log        |
                         +----------+-----------+
                                    |
                         +----------v-----------+
                         | Module 5             |
                         | Account hierarchy    |
                         | polymorphic batch    |
                         +----------------------+
```

## 5. Class diagram

```text
                  +------------------------------+
                  | Account                      |
                  |------------------------------|
                  | total_accounts (class attr)  |
                  | _account_id (protected)      |
                  | __balance (private)          |
                  |------------------------------|
                  | get_balance / set_balance     |
                  | get_account_id / set_account_id|
                  | process_settlement()          |
                  +---------------+--------------+
                                  |
              +-------------------+-------------------+
              |                   |                   |
   +----------v---------+ +-------v----------+ +------v-----------+
   | SavingsAccount     | | CurrentAccount   | | CreditAccount    |
   |--------------------| |------------------| |------------------|
   | minimum balance    | | __overdraft_limit| | __credit_limit   |
   | 1000               | | private          | | private          |
   +--------------------+ +------------------+ +------------------+

Exception hierarchy:
Exception
  └── BaseSystemError
      ├── CorruptedRecordError
      ├── OutOfBoundsError
      └── InsufficientBalanceError
```

## 6. Source code guide by path and section

All required source code is in **`main.py`**; the SRS explicitly calls for one source file. The headings in the source separate the five modules.

| Path / function or class | Purpose |
|---|---|
| `main.py` → `compound_interest`, `calculate_penalty`, `trajectory_guard`, `command_loop` | Unit 1: nested loops, arithmetic-only financial calculations, short-circuit trajectory guard and CLI |
| `main.py` → `parse_raw_log_line` | Unit 2: hand-written delimiter parser; quoted delimiters, doubled quotes, empty fields and trailing delimiter |
| `main.py` → `create_audit_filter` | Unit 2: closure with `nonlocal` audit count |
| `main.py` → `build_positional_filters` | Unit 2: loop-created lambdas with `k=index` default binding |
| `main.py` → `build_reverse_index` | Unit 3: nested comprehension and unique, sorted reverse index |
| `main.py` → `clean_transaction_queue` | Unit 3: modifies the supplied list object in place |
| `main.py` → exception classes and file functions | Unit 4: validation, in-place `r+`-style binary record update, logging and fault isolation |
| `main.py` → `Account`, `SavingsAccount`, `CurrentAccount`, `CreditAccount` | Unit 5: encapsulation, inheritance, overriding and settlement rules |
| `main.py` → `execute_batch_settlement` | Unit 5: each settlement is isolated in its own `try-except` |
| `main.py` → `run_demonstrations`, `main` | Runs requirement demonstrations and then the CLI |

## 7. Account file format

`accounts.db` contains one record per line, in this format:

```text
Acc101, SAVINGS, 5200.00
Acc102, CURRENT, 1200.00
Acc103, CREDIT, 2500.00
```

Each record must have exactly three fields: account ID, account type (`SAVINGS`, `CURRENT`, or `CREDIT`), and non-negative numeric balance. Invalid rows are logged to `corrupted.log`; valid rows are recorded in `ledger.txt`.

**Important:** `update_account_record_in_place(account_id, new_balance, db_path="accounts.db")` is available for a direct in-place record update. It opens the file in `r+b` mode, shifts the following bytes in bounded chunks when record length changes, and writes a ledger entry. Call it from Python or add a CLI command if your instructor requests an interactive update operation.

## 8. State and scope tracking table

| State / name | Scope or visibility | Purpose |
|---|---|---|
| `audited_count` in `create_audit_filter` | Enclosing function scope; updated by `nonlocal` | Maintains an independent count for each generated audit filter |
| `index`, `balance`, `history` in functions | Local | Loop and operation state; not shared globally |
| `k=index` in each lambda | Default argument bound when lambda is created | Prevents late-binding errors |
| `Account.__balance` | Private by name mangling | Internal account balance |
| `_account_id` | Protected naming convention | Account identifier used by subclasses |
| `Account.total_accounts` | Class attribute | Counts constructed account objects |
| `CurrentAccount.__overdraft_limit` | Private by name mangling | Limits current-account overdraft |
| `CreditAccount.__credit_limit` | Private by name mangling | Limits credit-account usage |
| `__overdraft_used`, `__credit_used` | Private implementation state | Tracks usage beyond a non-negative stored balance |

No global variables are used to pass state into closures or to fix lambda late binding. The program's module-level definitions are functions/classes/constants rather than mutable global state used by closures.

## 9. Module compliance checklist (Units 1–5)

### Unit 1 — loops, logic and arithmetic
- [x] Interactive loop continues until explicit `exit`.
- [x] Interest and penalty use arithmetic operators rather than `math`.
- [x] Trajectory guard demonstrates early stopping on low balance and termination flag.

### Unit 2 — functions, scope, slicing and parsing
- [x] Parser manually scans characters and tracks quote state.
- [x] Quoted delimiters, doubled quotes, empty fields and trailing delimiter are handled.
- [x] Audit closure uses `nonlocal`.
- [x] Positional lambdas bind the loop index as a default argument.

### Unit 3 — comprehensions and sequences
- [x] Reverse index maps each service tag to sorted unique `(Account_ID, Branch_ID)` tuples.
- [x] Queue is mutated without rebinding the top-level list.
- [x] Tuples are converted to lists; sets have even integer values removed; embedded lists are sorted descending.
- [x] Duplicate primitive values are removed by scanning and deleting by index.

### Unit 4 — file I/O and exceptions
- [x] Custom exception hierarchy derives from `BaseSystemError`.
- [x] Records are validated independently; invalid records are logged with line numbers.
- [x] Accepted records/updates are written to `ledger.txt`.
- [x] File operations use context managers.
- [x] The update function shifts the tail in chunks rather than loading and rewriting the entire file.

### Unit 5 — classes and polymorphism
- [x] `Account` includes private balance, protected account ID and class-level account count.
- [x] Getters/setters validate values.
- [x] Savings, current and credit account classes override settlement.
- [x] Batch settlement catches each account's failure independently.
- [x] Demonstration shows mangled access and expected failure of `obj.__balance`.

## 10. Test and demonstration notes

On startup, `run_demonstrations()` prints examples for arithmetic, trajectory guards, parsing, closures, lambda binding, reverse indexing, in-place queue cleanup, file validation, name mangling, and polymorphic settlements.

Useful manual checks:
1. Parser: `parse_raw_log_line('A,"B,C",D')` should return `['A', 'B,C', 'D']`.
2. Escaped quote: `parse_raw_log_line('"Customer ""A""",UPI,100')` should return `['Customer "A"', 'UPI', '100']`.
3. Trailing delimiter: `parse_raw_log_line('Acc101,SAVINGS,')` should return `['Acc101', 'SAVINGS', '']`.
4. Queue identity: compare `id(queue)` before and after `clean_transaction_queue(queue)`.
5. Batch isolation: a rejected settlement should not prevent subsequent account objects from being processed.
6. File safety: make a backup of `accounts.db` before calling `update_account_record_in_place`.

## 11. Known interpretation notes

- The SRS specifies a CLI plus demonstrations, not a GUI or web application.
- The in-place record update is exposed as a function; the required CLI command list in this implementation remains the documented four commands.
- Overdraft/credit exposure is tracked separately from the base account's non-negative stored balance so the base setter can continue enforcing non-negative balances.
